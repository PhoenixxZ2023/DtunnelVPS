# DtunnelVPS

# Comando para instalação
```bash <(wget -qO- https://raw.githubusercontent.com/UlekBR/DtunnelVPS/refs/heads/main/install.sh)```